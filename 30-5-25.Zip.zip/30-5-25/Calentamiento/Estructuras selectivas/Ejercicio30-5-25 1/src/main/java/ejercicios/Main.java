package ejercicios;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Escriba un numero: ");
        int Numero = scanner.nextInt();
        if(Numero > 0){
            System.out.println("El numero es positivo.");
        }
        else if(Numero == 0){
            System.out.println("El numero es cero");
        }
        else {
            System.out.println("El numero es negativo");
        }
    }
}