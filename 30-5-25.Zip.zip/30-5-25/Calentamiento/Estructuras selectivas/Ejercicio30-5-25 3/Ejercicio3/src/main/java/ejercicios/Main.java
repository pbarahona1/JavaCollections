package ejercicios;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Escriba un numero");
        int num1 = scanner.nextInt();
        System.out.println("Escriba otro numero");
        int num2 = scanner.nextInt();
        System.out.println("¿Que quiere hacer con esos numero?");
        System.out.println("Opcion 1: Suma, Opcion 2: Multiplicacion, Opcion 3: division, Opcion 4: Resta");
        int opcion = scanner.nextInt();
        scanner.close();
        switch (opcion){
            case 1:
                System.out.println("Usted eligio suma: " + num1 + num2);
                break;
            case 2:
                System.out.println("usted eligio multiplicar: " + num1 * num2);
                break;
            case 3:
                System.out.println("Usted eligio division: " + num1%num2);
                break;
            case 4:
                System.out.println("Usted eligio resta: " + (num1 - num2));
                break;
            default:
                System.out.println("Lo que usted digito no es una de las opciones");
        }
    }
}