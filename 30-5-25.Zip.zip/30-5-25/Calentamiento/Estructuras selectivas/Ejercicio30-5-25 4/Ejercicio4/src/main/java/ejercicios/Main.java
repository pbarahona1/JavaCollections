package ejercicios;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Escriba su nota: ");
        int nota = scanner.nextInt();

        if (nota >= 6 && nota <= 10){
            System.out.println("Usted aprobo");
        }
        else if (nota < 6 && nota >= 1){
            System.out.println("Usted reprobo");
        }
        else{
            System.out.println("Su nota no esta bien colocada debe de ser del 1 al 10");
        }
    }
}