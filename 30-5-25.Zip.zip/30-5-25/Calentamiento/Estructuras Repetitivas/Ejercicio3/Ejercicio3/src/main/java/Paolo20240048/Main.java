package Paolo20240048;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        int tabla = 1;
        int multiplicador = 1;
        int resultado = 0;

        System.out.println("Tabla de multiplicar del " + tabla);

        while (tabla <= 10) {
            resultado = tabla * multiplicador;
            System.out.println(tabla + "*" + multiplicador + "=" + resultado);
            multiplicador = multiplicador + 1;

            if (multiplicador == 11 && tabla < 11) {
                System.out.println("Tabla de multiplicar del " + tabla);
                multiplicador = 1;
                tabla = tabla + 1;
            }
        }
    }
}