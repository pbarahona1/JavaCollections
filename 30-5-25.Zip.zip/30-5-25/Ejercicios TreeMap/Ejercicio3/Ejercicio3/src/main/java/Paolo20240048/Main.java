package Paolo20240048;
import java.util.Map;
import java.util.TreeMap;
//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
// Crear TreeMap: clave = nombre del jugador, valor = puntaje
        TreeMap<String, Integer> puntajes = new TreeMap<>();

        puntajes.put("van Dijk", 89);
        puntajes.put("Cristiano Ronaldo", 86);
        puntajes.put("Mbappé", 91);
        puntajes.put("Messi", 88);
        puntajes.put("Raphinha", 84);

        System.out.println("Ranking de jugadores (ordenados por nombre):");
        for (Map.Entry<String, Integer> entry : puntajes.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }

        String mejorJugador = null;
        int mejorPuntaje = Integer.MIN_VALUE;

        for (Map.Entry<String, Integer> entry : puntajes.entrySet()) {
            if (entry.getValue() > mejorPuntaje) {
                mejorPuntaje = entry.getValue();
                mejorJugador = entry.getKey();
            }
        }

        System.out.println("\nJugador con el puntaje más alto:");
        System.out.println(mejorJugador + ": " + mejorPuntaje);
    }

}