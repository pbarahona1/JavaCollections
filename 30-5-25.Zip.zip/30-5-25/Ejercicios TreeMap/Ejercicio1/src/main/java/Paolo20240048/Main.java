package Paolo20240048;

import java.util.Map;
import java.util.TreeMap;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        TreeMap<String, Double> productos = new TreeMap<>();
        productos.put("Pan", 0.75);
        productos.put("Leche", 1.25);
        productos.put("Huevos", 2.50);
        productos.put("Queso", 3.80);

        double total = 0;


        System.out.println("Lista de productos:");
        for (Map.Entry<String, Double> entry : productos.entrySet()) {
            System.out.println(entry.getKey() + " - $" + entry.getValue());
            total += entry.getValue();
        }

        System.out.println("\nTotal a pagar: $" + total);
    }
}