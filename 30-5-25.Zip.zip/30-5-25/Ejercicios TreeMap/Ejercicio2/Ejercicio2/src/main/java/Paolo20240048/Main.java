package Paolo20240048;
import java.util.Map;
import java.util.TreeMap;
//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        TreeMap<String, Double> temperaturas = new TreeMap<>();

        temperaturas.put("Bogotá", 14.5);
        temperaturas.put("Quito", 16.0);
        temperaturas.put("Lima", 19.3);
        temperaturas.put("Buenos Aires", 22.1);
        temperaturas.put("Caracas", 27.8);

        System.out.println("Ciudades y sus temperaturas (orden alfabético):");
        for (Map.Entry<String, Double> entry : temperaturas.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue() + " °C");
        }

        String ciudadMasFria = null;
        String ciudadMasCalida = null;
        double tempMin = Double.MAX_VALUE;
        double tempMax = Double.MIN_VALUE;

        for (Map.Entry<String, Double> entry : temperaturas.entrySet()) {
            if (entry.getValue() < tempMin) {
                tempMin = entry.getValue();
                ciudadMasFria = entry.getKey();
            }

            if (entry.getValue() > tempMax) {
                tempMax = entry.getValue();
                ciudadMasCalida = entry.getKey();
            }
        }

        System.out.println("\nCiudad más fría: " + ciudadMasFria + " (" + tempMin + " °C)");
        System.out.println("Ciudad más cálida: " + ciudadMasCalida + " (" + tempMax + " °C)");
    }
}
