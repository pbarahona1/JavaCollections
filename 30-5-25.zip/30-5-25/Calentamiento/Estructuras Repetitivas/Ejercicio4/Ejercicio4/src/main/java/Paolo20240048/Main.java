package Paolo20240048;

import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int contador = 0;
        int numero;

        System.out.println("Ingrese números (ingrese 0 para terminar):");

        while (true) {
            System.out.print("Ingrese un número: ");
            numero = scanner.nextInt();

            if (numero == 0) {
                break;
            } else {
                contador++;
            }
        }

        System.out.println("La cantidad de números ingresados es: " + contador);

        scanner.close();
    }

}
