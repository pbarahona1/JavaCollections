package Paolo20240048;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        int num;
        System.out.println("Secuencia de numero del 1 al 10");
        for (num=1; num<=10; num++){
            System.out.println(num+ ",");
        }
    }
    }
