package Paolo20240048;

import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Bienvenido");
        System.out.println("Elija una opcion");
        System.out.println("1.Menu, 2.Perfil, 3.cerrar sesión");
        int opcion = scanner.nextInt();
        switch (opcion){
            case 1:
                System.out.println("----Menu----");
                System.out.println("Elija una opcion: ");
                System.out.println("1. Inicio, 2. Configuracion, 3. Contactenos, 4.Cerrar sesión");
                int opcionMenu = scanner.nextInt();
                switch (opcionMenu){
                    case 1:
                        System.out.println("----Inicio----");
                        System.out.println("Elija una opcion");
                        System.out.println("1.Cerrar sesión");
                        int cerrarmenu = scanner.nextInt();

                        switch (cerrarmenu){
                            case 1:
                                System.out.println("Elijio cerrar sesión");
                                break;

                            default:
                                System.out.println("La opcion que elijio no existe. se cerrara sesión");
                                break;
                        }
                    case 2:
                        System.out.println("---Configuracion");
                        System.out.println("Aqui ira su configuracion del perfil");
                        System.out.println("Se cerrara sesión");
                        break;

                    case 3:
                        System.out.println("---Contactenos---");
                        System.out.println("Puede contactarnos al 1111-1111 o al correo institucional" +
                                "20240048@ricaldone.edu.sv");
                        break;

                    case 4:
                        System.out.println("---Cerrar Sesión---");
                        System.out.println("Elijio cerrar sesión");
                        break;
                    default:
                        System.out.println("La opcion que elijio no existe. se cerrara sesión");
                        break;
                }break;
            case 2:
                System.out.println("---Configuracion---");
                System.out.println("Elija una opcion");
                System.out.println("1. Ver perfil, 2.Cerrar sesión, 3.Ver creador de la pagina");
                int ConfiguracionOpcion = scanner.nextInt();
                switch (ConfiguracionOpcion){
                    case 1:
                        System.out.println("---perfil---");
                        System.out.println("Aqui se mostrara su perfil");
                        System.out.println("Elija una opcion");
                        System.out.println("1.Cerrar sesión");
                        int CerrarPerfil = scanner.nextInt();
                        switch (CerrarPerfil){
                            case 1:
                                System.out.println("Elijio cerrar sesión");
                                break;
                            default:
                                System.out.println("La opcion que elijio no existe. se cerrara sesión");
                                break;
                        }
                    case 2:
                        System.out.println("---Cerrar Sesión---");
                        System.out.println("Elijio cerrar sesión");
                        break;

                    case 3:
                        System.out.println("---Creador---");
                        System.out.println("El creador de esta pagina fue Paolo Alerto Barahona Zepeda " +
                                "con codigo 20240048. Estudia en el Instituto Tecnico Ricaldone, " +
                                "Actualmente esta en 2 año de bachierato.");
                        break;

                    default:
                        System.out.println("La opcion que elijio no existe. se cerrara sesión");
                        break;
                }break;
            case 3:
                System.out.println("---Cerrar Sesión---");
                System.out.println("Usted eligio cerrar sesión");
                break;

            default:
                System.out.println("La opcion que elijio no existe. se cerrara sesión");
                break;
        }
    }
}
