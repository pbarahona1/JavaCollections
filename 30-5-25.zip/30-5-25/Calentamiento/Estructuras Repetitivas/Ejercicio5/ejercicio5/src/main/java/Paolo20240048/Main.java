package Paolo20240048;

import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Crea aqui tu contraseña nueva: ");
        String contraseña = scanner.nextLine();

        String contraseñasIntentos;
        int numero = 0;

        for (int i = 1; i <= 3; i++) {
            System.out.println("Ingresa tu contraseña: ");
            contraseñasIntentos = scanner.nextLine();

            if (contraseñasIntentos.equals(contraseña))  {
                numero += 1;
                break;
            }
        }

        if (numero == 1) {
            System.out.println("Ingresaste la contraseña correcta ");
        }
        else {
            System.out.println("Ninguna es la contraseña correcta.");
        }
    }
}