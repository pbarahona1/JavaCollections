package Paolo20240048;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        int n = 10;
        int suma = 0;

        for (int i = 1; i<=n; i++){
            suma += i;
        }
        System.out.println("La suma de los primeros " + n + " números naturales es: " + suma);
    }
}