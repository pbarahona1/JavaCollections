package Paolo20240048;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
                Scanner scanner = new Scanner(System.in);

                System.out.print("Ingrese el precio del producto: ");
                double precio = scanner.nextDouble();

                System.out.print("Ingrese el porcentaje de descuento: ");
                double descuento = scanner.nextDouble();

                double descuentoAplicado = precio * (descuento / 100);

                double precioFinal = precio - descuentoAplicado;

                System.out.println("Precio original: " + precio);
                System.out.println("Descuento aplicado: " + descuentoAplicado);
                System.out.println("Precio final: " + precioFinal);
                scanner.close();
            }
    }