package Paolo20240048;

import java.util.HashSet;
import java.util.Set;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Set<String> Usuario = new HashSet<>();

        //Añadir Usuarios
        Usuario.add("Paolo");
        Usuario.add("Kenneth");
        Usuario.add("Paolo");//Repetido
        Usuario.add("Rodrigo");
        Usuario.add("Kenneth");//Repetido

        System.out.println("Usuarios que hay: " + Usuario);

        System.out.println("¿Usuarios contiene a Rodrigo? " + Usuario.contains("Rodrigo"));
    }
}