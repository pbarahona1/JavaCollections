package Paolo20240048;

import java.util.Collections;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Scanner Codigo = new Scanner(System.in);
        HashSet<String> codigos = new HashSet<String>();
        String codigo;

        System.out.println("Control de asistentes al evento");
        System.out.println("Escribe los códigos. Escribe 'fin' para terminar.");

        while (true) {
            System.out.print("Código: ");
            codigo = Codigo.nextLine();

            if (codigo.equals("fin")) {
                break;
            }

            if (codigos.contains(codigo)) {
                System.out.println("Ya registrado");
            } else {
                codigos.add(codigo);
                System.out.println("Registrado con éxito");
            }
        }

        System.out.println("\nLista de asistentes únicos:");
        for (String c : codigos) {
            System.out.println(c);
        }
    }
}