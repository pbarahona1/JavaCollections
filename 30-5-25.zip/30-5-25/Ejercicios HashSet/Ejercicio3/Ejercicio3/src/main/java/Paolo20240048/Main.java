package Paolo20240048;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Scanner Palabra = new Scanner(System.in);
        HashSet<String> palabras = new HashSet<String>();
        String palabra;

        System.out.println("Escribe palabras. Escribe 'fin' para terminar.");

        while (true) {
            System.out.print("Palabra: ");
            palabra = Palabra.nextLine();

            if (palabra.equals("fin")) {
                break;
            }

            palabras.add(palabra);
        }

        System.out.println("\nPalabras únicas en MAYÚSCULAS:");
        for (String p : palabras) {
            System.out.println(p.toUpperCase());
        }
    }
}